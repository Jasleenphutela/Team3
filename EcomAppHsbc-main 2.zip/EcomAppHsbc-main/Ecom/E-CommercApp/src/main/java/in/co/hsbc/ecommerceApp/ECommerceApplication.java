package in.co.hsbc.ecommerceApp;


public class ECommerceApplication  {
    public static void main(String[] args) {

    }
}
